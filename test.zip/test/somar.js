var soma = function (a,b) {

 return a+b;

}

module.exports = soma;
