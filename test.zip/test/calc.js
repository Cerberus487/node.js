var somafunc = require("./somar.js");
var divfunc =  require("./dividir.js");
var subfunc =  require("./sub.js");
var multfunc = require("./mult.js");

 console.log(somafunc(1,2));
 console.log(divfunc(40,20));
 console.log(subfunc(100,50));
 console.log(multfunc(100,10));
