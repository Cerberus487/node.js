var nome = "luis"
var sobrenome = "eduardo"

console.log(nome + " " + sobrenome );
