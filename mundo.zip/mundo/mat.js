var num = 20
var num2 = 30

 function somar(a,b) {
   return a + b;

 }
 console.log(somar(num,num2));
